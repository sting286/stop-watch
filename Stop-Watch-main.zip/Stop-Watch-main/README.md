# Stop-Watch
Using HTML,CSS,JavaSript
web link:- https://majestic-shortbread-762910.netlify.app
Output:-
<img width="426" alt="stop-watch" src="https://user-images.githubusercontent.com/114457826/192466445-db231190-37a9-4f08-9d67-2740b1fb94f4.png">
